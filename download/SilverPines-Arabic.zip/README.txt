Silver Pines — Arabic translation, version 1.0.0
Translation: Abdullah Hadi (عبدالله هادي)

MANUAL INSTALL (2 minutes)
1) Close the game.
2) In Steam: right-click Silver Pines -> Manage -> Browse local files.
3) From the zip, copy the Carpenter_Data folder into the game folder and choose Replace.
   (It replaces 101 files in Carpenter_Data\StreamingAssets\aa\StandaloneWindows64.)
4) Start the game and keep the language on English: the Arabic text shows in its place.

The file names must stay exactly as they are; a file next to the original under another name is ignored.

BACK TO ENGLISH
Steam: right-click the game -> Properties -> Installed Files -> Verify integrity of game files.

NOTES
- Voices stay in English; the translation covers the text.
- Pictures with English writing (signs, newspapers) stay in English in this version.
- A game update restores the original files: copy the translation again after an update.
- SHA256SUMS.txt lists the checksum of every file.
